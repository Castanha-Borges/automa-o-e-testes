// imc.test.js
const fs = require('fs');
const path = require('path');

let calcular;
let resultado;

beforeEach(() => {
    document.body.innerHTML = fs.readFileSync(path.resolve(__dirname, '../src/index.html'), 'utf-8');

    calcular = document.getElementById('calcular');
    resultado = document.getElementById('resultado');
});

test('deve calcular IMC corretamente para peso ideal', () => {
    document.getElementById('nome').value = 'João';
    document.getElementById('altura').value = 1.75; // 1.75 m
    document.getElementById('peso').value = 70; // 70 kg

    calcular.click();

    expect(resultado.textContent).toContain('seu IMC é 22.9 e você está com peso ideal. Parabéns!!!');
});

test('deve calcular IMC corretamente para abaixo do peso', () => {
    document.getElementById('nome').value = 'Maria';
    document.getElementById('altura').value = 1.60; // 1.60 m
    document.getElementById('peso').value = 45; // 45 kg

    calcular.click();

    expect(resultado.textContent).toContain('seu IMC é 17.6 e você está abaixo do peso.');
});

test('deve retornar mensagem de erro se campos estiverem vazios', () => {
    calcular.click();
    
    expect(resultado.textContent).toBe('Preencha todos os campos!!!');
});
